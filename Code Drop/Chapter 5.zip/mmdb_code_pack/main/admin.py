from django.contrib import admin

from main.models import MovieDetails


admin.site.register(MovieDetails)
